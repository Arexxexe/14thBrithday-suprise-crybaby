## Cute Birthday Cake App I made for my boyfriend : ) 

## Here are the steps to use this

#### Cloning
`git clone https://github.com/tinabyte/happybdaymonkey`

#### Installing dependencies
go to project directory and `npm i` or `npm install`

#### Running the project
go to project directory and `npm start`




## Follow my github to follow along my projects (^_−)−☆


https://github.com/user-attachments/assets/d2a3a3c2-eba5-49c0-9bc6-bb4a0c01784b

